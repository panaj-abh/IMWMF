clc;close all;clear;
if isfile("log.txt"),delete("log.txt");end
diary("log.txt");%Record to Log file
addpath(pwd+"\matlabPyrTools");%PyrTools required for VIF
global W1 W2 W3 W4 OriImg
p=0.125;%Minkowski distance of order p=0.125(best results among p=0.0625,0.125,0.25,0.5,1,2 in many datasets)
%Precompute weight matrix. If use adaptive size in loop(obsolete), precompute will reduce execution time
W1=ComputeMinkowskiWeightMatrix(p,1);W2=ComputeMinkowskiWeightMatrix(p,2);
W3=ComputeMinkowskiWeightMatrix(p,3);W4=ComputeMinkowskiWeightMatrix(p,4);OriImg=[];
AllowedImgExtension={'jpg','jpeg','png'};%Process only these image extensions(can add more)

%SkipThisDataset={'Test_dataset'};%Use this one for faster testing
SkipThisDataset={'traditional_dataset','BSDS_dataset','TESTIMAGES_dataset'};%Skip for faster testing

%Get all folders with _dataset(case insensitive use Regular Expression to match folder name)
files=dir;AllUsedFolders={files([files.isdir]).name};
AllUsedFolders=AllUsedFolders(~cellfun(@isempty,regexp(AllUsedFolders,"_(?i)dataset")));
AllUsedFolders=AllUsedFolders(~ismember(AllUsedFolders,SkipThisDataset));%Remove skip list
DatasetCount=0;DatasetList={};TotalUsedFolders=size(AllUsedFolders,2);
SummaryTablesArray=cell(1,TotalUsedFolders); SummaryTablesExcTime=cell(1,TotalUsedFolders);
%Loop all folders and process all image files
for fol=AllUsedFolders
    files=dir(pwd+"\"+fol);AllUsedFiles={files(~[files.isdir]).name};%Get all files in folder
    AllUsedFiles=AllUsedFiles(~cellfun(@isempty,regexp(AllUsedFiles,...
        "\.(?i)("+strjoin(AllowedImgExtension,"|")+")$")));%Match all file with allowed extensions
    if size(AllUsedFiles,2)>0
        DatasetCount=DatasetCount+1;
        DatasetName=regexp(fol,".*(?=_(?i)dataset)",...
            "match");%Get datasets name(use Positive Lookahead RegEx to match every thing before _dataset)
        disp("////Processing "+DatasetName{1}+" image dataset////"); DatasetList(end+1)={char(DatasetName{1})};
        ImgDataset=string(fol+"\"+AllUsedFiles);
        MethodName={'IMF(Mode=1)','IMF(Mode=2)','Proposed'};%Name of each method in ResultsArray
        ResultsArray=cell(1,3);%3=#Total methods used
        ResultsArray{1}=ProcessDataset(DatasetName,ImgDataset,"IMF",1);
        ResultsArray{2}=ProcessDataset(DatasetName,ImgDataset,"IMF",2);
        ResultsArray{3}=ProcessDataset(DatasetName,ImgDataset,"Proposed",2,p);
        if size(AllUsedFiles,2)>5 %Normal case use 4 significant digits
            SummaryTables=GetSummaryTable(ResultsArray,MethodName,"Algorithm","Criterion","Significant");
        else %For small image dataset use fixed 4 digits(for Test dataset)
            SummaryTables=GetSummaryTable(ResultsArray,MethodName,"Algorithm","Criterion","FixedDigits");
        end
        SummaryTablesArray{DatasetCount}=SummaryTables;
        SummaryTablesExcTime{DatasetCount}=GetOneMetricTable(ResultsArray,MethodName,"ExecutionTime",0);
    end
end
if DatasetCount>0
    ResultsExcTime=0;
    for i=1:DatasetCount
        disp("    Summary of denoising results for the "+DatasetList{i}+" image dataset with different SPN ratios.");
        disp(SummaryTablesArray{i});
        Tmp=SummaryTablesExcTime{i};%ExecutionTime
        if istable(ResultsExcTime), ResultsExcTime{:,:}=ResultsExcTime{:,:}+Tmp{:,:}; else, ResultsExcTime=Tmp; end
    end
    ResultsExcTime{:,:}=round(ResultsExcTime{:,:}/DatasetCount,2);%Overall Mean
    ResultsExcTime=rows2vars(ResultsExcTime,"VariableNamingRule","preserve");
    ResultsExcTime=renamevars(ResultsExcTime,1,"Noise Density");
    ResultsExcTime.("Noise Density")=categorical(ResultsExcTime{:,1});
    disp("    Execution time comparison of the methods(averaged from "+DatasetCount+" image datasets).");
    disp(ResultsExcTime);
end

disp("////Processing House, Peppers, and Lena images////");
MiniComparison(p,"House",im2gray(imread("house.jpg")),0.6)
MiniComparison(p,"Peppers",im2gray(imread("peppers.jpg")),0.9)

ImgName={'Lena','Peppers','House'};%Name of each image in Results
ResultsPSNR=cell(1,3);%3=#Total image used
ResultsSSIM=cell(1,3);%3=#Total image used
MethodName={'IMF(Mode=1)','IMF(Mode=2)','Proposed'};%Name of each method in Results
ResultsHouse=cell(1,3);%3=#Total methods to show
ResultsHouse{1}=ProcessAllNoiseDensity("house.jpg","IMF",1,0,0);%disp(ResultsHouse{1});
ResultsHouse{2}=ProcessAllNoiseDensity("house.jpg","IMF",2,0,0);%disp(ResultsHouse{2});
ResultsHouse{3}=ProcessAllNoiseDensity("house.jpg","Proposed",2,0,0,p);%disp(ResultsHouse{3});
ResultsPSNR{3}=GetOneMetricTable(ResultsHouse,MethodName,"PSNR",1);%Get only PSNR data
ResultsSSIM{3}=GetOneMetricTable(ResultsHouse,MethodName,"SSIM",1);%Get only SSIM data
ResultsPeppers=cell(1,3);%3=#Total methods to show
ResultsPeppers{1}=ProcessAllNoiseDensity("peppers.jpg","IMF",1,0,0);%disp(ResultsPeppers{1});
ResultsPeppers{2}=ProcessAllNoiseDensity("peppers.jpg","IMF",2,0,0);%disp(ResultsPeppers{2});
ResultsPeppers{3}=ProcessAllNoiseDensity("peppers.jpg","Proposed",2,0,0,p);%disp(ResultsPeppers{3});
ResultsPSNR{2}=GetOneMetricTable(ResultsPeppers,MethodName,"PSNR",1);%Get only PSNR data
ResultsSSIM{2}=GetOneMetricTable(ResultsPeppers,MethodName,"SSIM",1);%Get only SSIM data
ResultsLena=cell(1,3);%3=#Total methods to show
ResultsLena{1}=ProcessAllNoiseDensity("lena.jpg","IMF",1,1,1);
ResultsLena{2}=ProcessAllNoiseDensity("lena.jpg","IMF",2,1,1);
ResultsLenaIMFpcode=ProcessAllNoiseDensity("lena.jpg","IMF",3,1,1);
ResultsLena{3}=ProcessAllNoiseDensity("lena.jpg","Proposed",2,1,1,p);
ResultsPSNR{1}=GetOneMetricTable(ResultsLena,MethodName,"PSNR",1);%Get only PSNR data
ResultsSSIM{1}=GetOneMetricTable(ResultsLena,MethodName,"SSIM",1);%Get only SSIM data
SummaryTablesPSNR=GetSummaryTable(ResultsPSNR,ImgName,"Image","Filters","Significant");
disp("    PSNR results of the methods for three traditional images with different SPN ratios.")
disp(SummaryTablesPSNR);
SummaryTablesSSIM=GetSummaryTable(ResultsSSIM,ImgName,"Image","Filters","Significant");
disp("    SSIM results of the methods for three traditional images with different SPN ratios.")
disp(SummaryTablesSSIM);

diary off;
function MiniComparison(p,ImgName,U,nd)
    rng(13,"twister")%RNG using Mersenne Twister, fix seed#13 for repeatability
    B=imnoise(U,"salt & pepper",nd);%U=Original Image,nd=Noise Density
    [IMFMode1,~,~]=ApplyIMF(B,1,0); [IMFMode2,~,~]=ApplyIMF(B,2,0); [Proposed,~,~]=ApplyProposed(B,p,2,0);
    figure; t=tiledlayout(2,3,"TileSpacing","tight"); nexttile, imshow(U); title("Original Image");
    nexttile, imshow(B); title("Corrupted by "+num2str(nd*100)+"% Salt & Pepper Noise"); nexttile,imshow([]);
    nexttile, imshow(IMFMode1);title({"Denoising results of IMF Mode=1",GetMetricsStr(IMFMode1,B,U)});
    nexttile, imshow(IMFMode2);title({"Denoising results of IMF Mode=2",GetMetricsStr(IMFMode2,B,U)});
    nexttile, imshow(Proposed);title({"Denoising results of Proposed p="+p,GetMetricsStr(Proposed,B,U)});
    xlabel(t,[ImgName+" image ("+size(U,1)+"x"+size(U,2)+" pixels)",...
        "(PSNR, SSIM, VIF, IEF, MSSIM)"],"fontweight","bold");
end
function MetricsStr=GetMetricsStr(A,B,U)%Called by MiniComparison
	PSNR=ComputePSNR(A,U); SSIM=ssim(A,U);
	[~,VIF]=evalc('vifvec(A,U)');%Not show log from vifvec
    IEF=ComputeIEF(A,B,U); MSSIM=multissim(A,U);
    MetricsStr="("+PSNR+" dB, "+SSIM+", "+VIF+", "+IEF+", "+MSSIM+")";
end
function OneMetricTable=GetOneMetricTable(InputArray,RowNameLists,Criterion,DelLastCol)
    OneMetricTable=0;
    for i=1:size(InputArray,2)
        TmpTable=InputArray{i};
        TmpTable.Row(Criterion)={char(string(RowNameLists{i}))};%Filter only one metric
        TmpTable=TmpTable(RowNameLists{i},:);
        if istable(OneMetricTable)            
            OneMetricTable=[OneMetricTable;TmpTable];%Concat table
        else
            OneMetricTable=TmpTable;
        end
    end
    if DelLastCol, OneMetricTable(:,end)=[]; end    
end
function SummaryTable=GetSummaryTable(InputArray,FirstColLists,ColName1,ColName2,RoundType)
    SummaryTable=0;
    sr=size(InputArray{1}.Row,1); sc=size(InputArray{1}.Variables,2);
    for i=1:size(InputArray,2)
        TmpTable=addvars(InputArray{i},categorical(InputArray{i}.Properties.RowNames),...
            'Before',1,'NewVariableName',ColName2);TmpTable.Row=[];%Transform RowNames to Cols
        tmp=cell(sr,1);tmp(:)={char(0)};tmp(round(sr/2))={char(string(FirstColLists{i}))};%FirstCol
        TmpTable=addvars(TmpTable,categorical(tmp),'Before',1,'NewVariableName',ColName1);
        tmp=cell(1,sc+2);tmp(:)={char(0)};NullLine=array2table(categorical(tmp));%Separator NullLine
        NullLine.Properties.VariableNames=TmpTable.Properties.VariableNames;
        for j=TmpTable.Properties.VariableNames%Convert numeric to categorical for concat with NullLine
            if isnumeric(TmpTable.(string(j)))
                if RoundType=="Significant"
                    TmpTable.(string(j))=categorical(cellstr(num2str(TmpTable.(string(j)),"%#.4g")));
                else
                    TmpTable.(string(j))=categorical(cellstr(num2str(TmpTable.(string(j)),"%.4f")));
                end
            else
                TmpTable.(string(j))=categorical(TmpTable.(string(j)));
            end
        end
        if istable(SummaryTable)            
            SummaryTable=[SummaryTable;NullLine;TmpTable];%Concat table
        else
            SummaryTable=TmpTable;
        end
    end
end
function arg=getArg(Method,Mode,p)%Called by ProcessDataset,ProcessAllNoiseDensity
    switch Method
        case "Proposed"
            if Mode==1, tmp=", Stopping Criterion=|MAD Diff.|";...
            else, tmp=", Stopping Criterion=NoNoisePelLeft"; end
            arg=": p="+num2str(p)+tmp;
        case "IMF"
            if Mode==1, tmp=", Stopping Criterion=SAD";...
            else, tmp=", Stopping Criterion=NoNoisePelLeft"; end
            arg=": Mode="+Mode+tmp;
        otherwise
            error("Stop! Invalid method");
    end
end
function OverallAvgResults=ProcessDataset(DatasetName,ImgDataset,Method,Mode,p)
    switch nargin
        case 5, arg=getArg(Method,Mode,p);
        case 4, arg=getArg(Method,Mode);
        otherwise, error("Stop! Invalid number of input argument");
    end
    TotalImg=size(ImgDataset,2);
    disp("@@@@Processing "+Method+" Method"+arg+" on "+DatasetName+" image dataset@@@@");
    SumResultsTmp=0;
    for ImgName=ImgDataset
        if nargin==5,Tmp=ProcessAllNoiseDensity(string(ImgName),Method,Mode,0,0,p); else,...
            Tmp=ProcessAllNoiseDensity(string(ImgName),Method,Mode,0,0); end
        disp("-Avg.Results=("+strjoin(string(Tmp.Mean),", ")+")")
        if istable(SumResultsTmp)
            SumResultsTmp{:,:}=SumResultsTmp{:,:}+Tmp{:,:};
        else
            SumResultsTmp=Tmp;
        end
    end
    SumResultsTmp{:,:}=SumResultsTmp{:,:}/TotalImg;%Overall Mean
    OverallAvgResults=SumResultsTmp;
    disp("@@@@Avg.Results of "+Method+" Method"+arg+" on "+TotalImg+" images("+DatasetName+" dataset)@@@@");
    disp(OverallAvgResults);
end
function MetricsResults=ProcessAllNoiseDensity(ImgName,Method,Mode,Log,Plot,p)
    global OriImg
    MetricsList={'PSNR','SSIM','VIF','IEF','MSSIM','#Iteration','ExecutionTime'};
    NoiseDensityList=0.1:0.1:0.9; NoisePercentage=[string(100*(NoiseDensityList))+"%" "Mean"];
    switch nargin
        case 6, arg=getArg(Method,Mode,p);
        case 5, arg=getArg(Method,Mode);
        otherwise, error("Stop! Invalid number of input argument");
    end
    if Plot
        figure; t=tiledlayout(3,6,"TileSpacing","tight");
        xlabel(t,[Method+" Method"+arg,"(PSNR, SSIM, VIF, IEF, MSSIM)"],"fontweight","bold");
    end
    MetricsTmp=[];
    disp("####Applying "+Method+" Method"+arg+" ("+ImgName+")####");
    for nd=NoiseDensityList
        rng(13,"twister")%RNG using Mersenne Twister, fix seed#13 for repeatability
        OriImg=im2gray(imread(ImgName));%Original image
        B=imnoise(OriImg,'salt & pepper',nd);%Corrupted by Salt&Pepper noise
        if Log, disp("-For "+num2str(nd*100)+"% salt & pepper noisy image of "+ImgName); end
        switch Method
            case "Proposed"
                [OutImp,ExecutionTime,iteration]=ApplyProposed(B,p,Mode,Log);
            case "IMF"
                [OutImp,ExecutionTime,iteration]=ApplyIMF(B,Mode,Log);
        end
        PSNR=ComputePSNR(OutImp,OriImg); SSIM=ssim(OutImp,OriImg);
        [~,VIF]=evalc('vifvec(OutImp,OriImg)');%Not show log from vifvec
        IEF=ComputeIEF(OutImp,B,OriImg); MSSIM=multissim(OutImp,OriImg);
        if Log, disp("*PSNR="+PSNR+",SSIM="+SSIM+",VIF="+VIF+",IEF="+IEF+",MSSIM="+MSSIM+...
                "(TotalIteration="+iteration+",ExecutionTime="+ExecutionTime+"sec.)"); end
        tmp=[PSNR;SSIM;VIF;IEF;MSSIM;iteration;ExecutionTime];
        MetricsTmp=[MetricsTmp tmp];
        if Plot
            nexttile, imshow(B);title("Noise of "+num2str(nd*100)+"%");
            nexttile, imshow(OutImp);title({"Denoising of "+num2str(nd*100)+"%",...
                "("+PSNR+" dB, "+SSIM+", "+VIF+", "+IEF+", "+MSSIM+")"});
        end
    end
    MetricsTmp=[MetricsTmp mean(MetricsTmp,2)];
    MetricsResults=array2table(MetricsTmp,"VariableNames",NoisePercentage,"RowNames",MetricsList);
    if Log,disp("####Results of "+Method+" Method"+arg+" ("+ImgName+")####");disp(MetricsResults);end
end
function [OutImg,ExecutionTime,iteration]=ApplyIMF(B,Mode,Log)%Main IMF algorithm
%Mode=1: Literally follow the Flowchart&Algorithm1 in the paper(Stopping Criterion:SAD)
%Mode=2: Our Modified IMF (eqivalent to Mode=3)
%Mode=3: Use obfuscate P-Code file from the authors (They didn't reveal source code)
global OriImg %for PSNR calculation
    tic
    %if Log, disp("****Applying IMF (Mode="+Mode+")****");end
    if Mode==3 %Mode=3
        OutImg=IMF(B); iteration=NaN; ExecutionTime=toc;
        return
    end
    A=double(B);%Initialize A[0]=B
    r=1;%WS=2*r+1;%Window size (2*r+1)x(2*r+1)
    iteration=0;%k=0
    epsilon=0; stop=0; [m,n]=size(B); A_NextIter=zeros(m,n); %maxiteration=100;
    dmax=max(B(:)); dmin=min(B(:));
    A0_Padded=padarray(A,[r r],"replicate");%Replicate padding
    %Begin iterative loop
    while stop==0
        A_Padded=padarray(A,[r r],"replicate");%Replicate padding
        NoisePelLeft=size(A((A>=dmax)|(A<=dmin)),1);
        for i=1+r:m+r%Sliding window for all pixels
            for j=1+r:n+r
                aij=A_Padded(i,j);
                if Mode==2 %Mode=2
                    ak_ij=A0_Padded(i,j);%Aij[0]
                else %Mode=1
                    ak_ij=aij;%Aij[k]
                end
                if ak_ij>=dmax||ak_ij<=dmin
                    Wij=A_Padded(i-r:i+r,j-r:j+r);%Select mask from image
                    Wij_star=Wij((Wij<dmax)&(Wij>dmin));
                    if size(Wij_star,1)==0
                        A_NextIter(i-r,j-r)=aij;
                    else
                        A_NextIter(i-r,j-r)=round(mean(Wij_star));
                    end
                else
                    A_NextIter(i-r,j-r)=aij;
                end
            end
        end
        iteration=iteration+1;
        SAD=norm(A_NextIter-A,1);
        A=A_NextIter;
        %Stopping Criterion
        if Mode==2 %Mode=2
            %if (SAD<=epsilon)||(iteration>=maxiteration), stop=1;end
            if (NoisePelLeft<=0), stop=1;end
        else %Mode=1
            if SAD<=epsilon, stop=1;end
        end
        if Log
            disp("Iteration#"+iteration+"(k="+num2str(iteration-1)+"): "+...
                "#Noise pixels left="+NoisePelLeft+", SAD="+SAD+...
                ", PSNR="+ComputePSNR(uint8(A),OriImg))
        end
    end
    OutImg=uint8(A);
    ExecutionTime=toc;
end
function [OutImg,ExecutionTime,iteration]=ApplyProposed(B,p,Criterion,Log)%Main Proposed algorithm
global OriImg %for PSNR calculation
    tic
    %if Log, disp("****Applying Proposed (p="+p+")****");end
    A=double(B);%Initialize A[0]=B
    r=1;%Window size (2*r+1)x(2*r+1)
    iteration=0;%k=0
    stop=0; [m,n]=size(B); A_NextIter=zeros(m,n); maxiteration=100;
    dmax=max(B(:)); dmin=min(B(:));
    A0_Padded=padarray(A,[r r],"replicate");%Replicate padding
    epsilon=0.0015; ToTalPel=m*n;
    W=GetMinkowskiWeightMatrix(p,r); MADlast=Inf;
    %Begin iterative loop
    while stop==0
        A_Padded=padarray(A,[r r],"replicate");%Replicate padding
        NoisePelLeft=size(A((A>=dmax)|(A<=dmin)),1);
        for i=1+r:m+r%Sliding window for all pixels
            for j=1+r:n+r
                aij=A_Padded(i,j);
                ak_ij=A0_Padded(i,j);%Repeat on denoised pixels
                if ak_ij>=dmax||ak_ij<=dmin
                    Wij=A_Padded(i-r:i+r,j-r:j+r);%Select mask from image
                    Wij_star=Wij((Wij<dmax)&(Wij>dmin));
                    if size(Wij_star,1)==0
                        A_NextIter(i-r,j-r)=aij;
                    else
                        W_star=W((Wij<dmax)&(Wij>dmin));
                        A_NextIter(i-r,j-r)=round(sum(Wij_star.*W_star)/sum(W_star));
                    end
                else
                    A_NextIter(i-r,j-r)=aij;
                end
            end
        end
        iteration=iteration+1;
        MAD=norm(A_NextIter-A,1)/ToTalPel;
        absMADdiff=abs(MAD-MADlast);
        MADlast=MAD;
        A=A_NextIter;
        %Stopping Criterion
        if Criterion==1 %Mode=1
            if (absMADdiff<=epsilon&&NoisePelLeft<=0)||(iteration>=maxiteration),stop=1;end
            %if (MAD<=epsilon&&TotalNoisePel<=0)||(iteration>=maxiteration),stop=1;end
        else %Mode=2
            if (NoisePelLeft<=0),stop=1;end
        end
        if Log
            disp("Iteration#"+iteration+"(k="+num2str(iteration-1)+"): "+...
                "#Noise pixels left="+NoisePelLeft+", MAD="+MAD+...
                ", |MAD_diff|="+absMADdiff+", PSNR="+ComputePSNR(uint8(A),OriImg))
        end
    end
    OutImg=uint8(A);
    ExecutionTime=toc;
end
%Minkowski distance weighted matrix
function W=GetMinkowskiWeightMatrix(p,r)
    global W1 W2 W3 W4
    switch r
        case 1,W=W1;case 2,W=W2;case 3,W=W3;case 4,W=W4;
        otherwise,W=ComputeMinkowskiWeightMatrix(p,r);
    end
end
function W=ComputeMinkowskiWeightMatrix(p,r)%Main Minkowski distance weighted matrix calculation
    [i,j]=ndgrid(1:(2*r+1),1:(2*r+1));
    c=cat(3,i,j);%coordinate
    W=zeros(2*r+1,2*r+1);
    for i=1:(2*r+1)
        for j=1:(2*r+1)
            W(i,j)=1/pdist([c(i,j,1) c(i,j,2);(r+1) (r+1)],"minkowski",p);
        end
    end
    W(r+1,r+1)=0;
end
%Criteria Functions
function PSNR=ComputePSNR(img,Original)
    MSE=mean(mean((double(img)-double(Original)).^2));PSNR=10*log10((2^8-1)^2/MSE);
end
function IEF=ComputeIEF(img,noisy,Original)
    IEF=sum(sum((double(noisy)-double(Original)).^2))...
        /sum(sum((double(img)-double(Original)).^2));
end
function vif=vifvec(imdist,imorg)%Visual Information Fidelity - Pixel (VIF-P)
%H. R. Sheikh and A. C. Bovik, "Image information and visual quality,"
%IEEE Trans. Image Process., vol. 15, no. 2, pp. 430-444, Jan. 2006. Code downloaded from
%https://github.com/sattarab/image-quality-tools/tree/master/metrix_mux/metrix/vif/vifvec_release
%Prerequisites: matlabPyrTools, available at https://github.com/LabForComputationalVision/matlabPyrTools
    M=3;subbands=[4 7 10 13 16 19 22 25];sigma_nsq=0.4;
    %Do wavelet decomposition.
    [pyr,pind]=buildSpyr(imorg, 4, 'sp5Filters', 'reflect1');%Compute transform
    org=ind2wtree(pyr,pind);%Convert to cell array
    [pyr,pind]=buildSpyr(imdist, 4, 'sp5Filters', 'reflect1');dist=ind2wtree(pyr,pind);
    %Calculate the parameters of the distortion channel
    [g_all,vv_all]=vifsub_est_m(org,dist,subbands,M);
    %Calculate the parameters of the reference image
    [ssarr, larr, cuarr]=refparams_vecgsm(org,subbands,M);
    vvtemp=cell(1,max(subbands));ggtemp=vvtemp;%Reorder subbands
    for kk=1:length(subbands)
        vvtemp{subbands(kk)}=vv_all{kk};ggtemp{subbands(kk)}=g_all{kk};
    end
    %Compute reference and distorted image information from each subband
    for i=1:length(subbands)
        sub=subbands(i);g=ggtemp{sub};vv=vvtemp{sub};ss=ssarr{sub};lambda=larr(sub,:);cu=cuarr{sub};
        neigvals=length(lambda);%How many eigenvalues to sum over. default is all
        %Compute the size of the window used in the distortion channel estimation, 
        %and use it to calculate the offset from subband borders
        lev=ceil((sub-1)/6);winsize=2^lev+1;offset=(winsize-1)/2;offset=ceil(offset/M);  
        %Select only valid portion of the output.
        g=g(offset+1:end-offset,offset+1:end-offset);vv=vv(offset+1:end-offset,offset+1:end-offset);
        ss=ss(offset+1:end-offset,offset+1:end-offset);
        temp1=0;temp2=0;%VIF
        for j=1:length(lambda)
            %Distorted image information for the i'th subband
            temp1=temp1+sum(sum((log2(1+g.*g.*ss.*lambda(j)./(vv+sigma_nsq)))));
            temp2=temp2+sum(sum((log2(1+ss.*lambda(j)./(sigma_nsq)))));%Reference image information
        end
        num(i)=temp1;den(i)=temp2;
    end
    vif=sum(num)./sum(den);%Compuate VIF
end
function wtree=ind2wtree(pyr,ind)%Called by vifvec
    C=pyr;S=ind;offset=0;numsubs=size(ind,1);
    for i=1:numsubs%Converts the output of Eero Simoncelli's pyramid routines into subbands in a cell array
        wtree{numsubs-i+1}=reshape(C(offset+1:offset+prod(S(i,:))), S(i,1),S(i,2));offset=offset+prod(S(i,:));
    end
end
function [g_all,vv_all]=vifsub_est_m(org,dist,subbands,M)%Called by vifvec
    %Uses convolution for determining the parameters of the distortion channel
    tol=1e-15;%Tolernace for zero variance
    for i=1:length(subbands)
        sub=subbands(i);y=org{sub};yn=dist{sub};
        %Compute the size of the window used in the distortion channel estimation
        lev=ceil((sub-1)/6);winsize=2^lev+1;offset=(winsize-1)/2;win=ones(winsize);
        %Force subband size to be multiple of M
        newsize=floor(size(y)./M)*M;y=y(1:newsize(1),1:newsize(2));yn=yn(1:newsize(1),1:newsize(2));
        %Correlation with downsampling
        winstep=[M M];winstart=[1 1].*floor(M/2)+1;winstop=size(y)-ceil(M/2)+1;
        mean_x=corrDn(y,win/sum(win(:)),'reflect1',winstep,winstart,winstop);
        mean_y=corrDn(yn,win/sum(win(:)),'reflect1',winstep,winstart,winstop);
        cov_xy=corrDn(y.*yn,win,'reflect1',winstep,winstart,winstop)-sum(win(:)).*mean_x.*mean_y;
        ss_x=corrDn(y.^2,win,'reflect1',winstep,winstart,winstop)-sum(win(:)).*mean_x.^2;
        ss_y=corrDn(yn.^2,win,'reflect1',winstep,winstart,winstop)-sum(win(:)).*mean_y.^2; 
        ss_x(ss_x<0)=0;ss_y(ss_y<0)=0;%Get rid of numerical problems, very small numbers
        g=cov_xy./(ss_x+tol);%Regression
        vv=(ss_y-g.*cov_xy)/(sum(win(:)));%Variance of error in regression
        %Get rid of numerical problems, very small numbers
        g(ss_x<tol)=0;vv(ss_x<tol)=ss_y(ss_x<tol);ss_x(ss_x<tol)=0;g(ss_y<tol)=0;vv(ss_y<tol)=0; 
        vv(g<0)=ss_y(g<0);g(g<0)=0;%Constrain g to be non-negative 
        vv(vv<=tol)=tol;%Take care of numerical errors, vv could be very small negative
        g_all{i}=g;vv_all{i}=vv;
    end
end
function [ssarr,l_arr,cu_arr]=refparams_vecgsm(org,subands,M)%Called by vifvec
    %Computes the parameters of the reference image
    for i=1:length(subands)
        sub=subands(i);y=org{sub};
        sizey=floor(size(y)./M)*M;%Crop to exact multiple size
        y=y(1:sizey(1),1:sizey(2));temp=[];
        %Collect MxM blocks, Rearrange each block into an M^2 dimensional vector and collect all
        %Collece ALL possible MXM blocks (even those overlapping) from the subband
        for j=1:M
            for k=1:M
                temp=cat(1,temp,reshape(y(k:end-(M-k), j:end-(M-j)),1,[]));
            end
        end
        %Estimate mean and covariance
        mcu=mean(temp')';cu=((temp-repmat(mcu,1,size(temp,2)))*(temp-repmat(mcu,1,size(temp,2)))')./size(temp,2);
        %Collect MxM blocks as above. Use ONLY non-overlapping blocks to calculate the S field
        temp=[];
        for j=1:M
            for k=1:M
                temp=cat(1,temp,reshape(y(k:M:end, j:M:end),1,[]));
            end
        end
        ss=(inv(cu)*temp);ss=sum(ss.*temp)./(M*M);ss=reshape(ss,sizey/M);%Calculate the S field
        [~,d]=eig(cu);l_arr(sub,:)=diag(d)';%Eigen-decomposition    
        ssarr{sub}=ss;temp=0;d=diag(d);cu_arr{sub}=cu;%Rearrange for output
    end
end
